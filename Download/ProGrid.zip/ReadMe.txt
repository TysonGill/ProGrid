Here is your ProGrid Demo Project and executable DLL.

BE SURE TO UNZIP THIS FOLDER BEFORE ATTEMPTING TO RUN ANYTHING.

Try out the demo program and play with the various ProGrid features.
We're sure you'll find it extremely easy to use with all the touches your users love.

We don't include documentation with the distribution. 
Rather, it is available on our support forum where you can always find current info:

http://surgicalgrade.net/forums/


ProGridComponent.DLL is all you need to reference and distribute with your project.

If you have not registered, the DLL displays a nag message periodically when you display a grid in design mode.


When you're ready to buy, you can order through our purchase page:

http://surgicalgrade.net/progrid/buy-it/


After you do, we will send you a license file that will disable the nag message.

Note that the demo project was built using Visual Studio 2010 or higher and the Microsoft .Net 4.0 framework.

Enjoy ProGridding!
